import React from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import About from './components/About';
import Solutions from './components/Solutions';
import CTA from './components/CTA';
import Footer from './components/Footer';

// Ensure these files exist in src/components/ui/ OR update the path
import SmoothScroll from './components/ui/SmoothScroll';
import Cursor from './components/ui/Cursor';

function App() {
  return (
    <SmoothScroll>
      <div className="bg-black min-h-screen w-full text-white font-sans selection:bg-cyan-500/30 selection:text-cyan-400">
        
        {/* 1. Custom Cursor (Hidden on mobile via CSS) */}
        <Cursor />
        
        {/* 2. Cinematic Grain Overlay */}
        <div className="bg-noise"></div>

        {/* 3. Navigation (Fixed on top) */}
        <Navbar /> 
        
        {/* 4. Main Content (Relative so it sits above grain) */}
        <main className="relative z-10 flex flex-col w-full">
          <section id="hero" className="w-full"><Hero /></section>
          <section id="about" className="w-full"><About /></section>
          <section id="solutions" className="w-full"><Solutions /></section>
          <section id="cta" className="w-full"><CTA /></section>
        </main>
        
        {/* 5. Footer */}
        <Footer />
        
      </div>
    </SmoothScroll>
  );
}

export default App;