import Navbar from "../components/Navbar";
import Hero from "../components/Hero";
import About from "../components/About";
import Solutions from "../components/Solutions";
import CTA from "../components/CTA";

export default function Home() {
  return (
    <>
      <Navbar />
      <Hero />
      <About />
      <Solutions />
      <CTA />
    </>
  );
}
