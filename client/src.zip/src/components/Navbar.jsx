import React, { useState, useEffect } from "react";
import { motion, AnimatePresence, useScroll, useMotionValueEvent } from "framer-motion";
import { Menu, X, Cloud, Zap, ShoppingBag, ArrowRight } from "lucide-react";
import { clsx } from "clsx";
import { twMerge } from "tailwind-merge";

// --- Utility for Tailwind ---
function cn(...inputs) {
  return twMerge(clsx(inputs));
}

// --- Navigation Links (Matched to your component files) ---
const LINKS = [
  { name: "About", href: "#about" },         // Links to your About.jsx section
  { name: "Solutions", href: "#solutions" }, // Links to your Solutions.jsx section
  { name: "Contact", href: "#cta" },         // Links to your CTA.jsx section
];

export default function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileOpen, setIsMobileOpen] = useState(false);
  const { scrollY } = useScroll();

  // Dynamic Scroll Detection
  useMotionValueEvent(scrollY, "change", (latest) => {
    const scrolled = latest > 50;
    if (scrolled !== isScrolled) setIsScrolled(scrolled);
  });

  // Lock body scroll when mobile menu is open
  useEffect(() => {
    if (isMobileOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "unset";
    }
  }, [isMobileOpen]);

  return (
    <>
      <motion.nav
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
        className={cn(
          "fixed top-0 left-0 right-0 z-[100] transition-all duration-500 ease-in-out border-b",
          isScrolled
            ? "bg-black/60 backdrop-blur-xl border-white/10 py-3 shadow-[0_0_30px_-10px_rgba(34,211,238,0.2)]"
            : "bg-transparent border-transparent py-6"
        )}
      >
        <div className="max-w-7xl mx-auto px-6 flex justify-between items-center relative">
          
          {/* --- BRAND LOGO --- */}
          <a href="#" className="group flex items-center gap-2 z-50">
            <div className="relative w-10 h-10 flex items-center justify-center bg-cyan-500/10 rounded-xl overflow-hidden border border-cyan-500/20 group-hover:border-cyan-400 transition-colors">
              <Cloud className="w-5 h-5 text-cyan-400 relative z-10 group-hover:scale-110 transition-transform duration-300" />
              {/* Animated Scanline Effect */}
              <div className="absolute inset-0 bg-gradient-to-t from-transparent via-cyan-400/20 to-transparent translate-y-[-100%] group-hover:translate-y-[100%] transition-transform duration-700" />
            </div>
            
            <div className="flex flex-col">
              <span className="text-xl font-black tracking-[0.2em] text-white leading-none">
                CANOPY
              </span>
              <span className="text-[10px] font-bold tracking-[0.4em] text-cyan-400 uppercase leading-none mt-1 group-hover:text-cyan-300 transition-colors">
                PUFFS
              </span>
            </div>
          </a>

          {/* --- DESKTOP MENU --- */}
          <ul className="hidden md:flex items-center gap-10">
            {LINKS.map((link) => (
              <li key={link.name} className="relative group overflow-hidden">
                <a
                  href={link.href}
                  className="text-sm font-medium text-gray-300 hover:text-white transition-colors relative z-10 block py-2"
                >
                  {link.name}
                </a>
                {/* Hover Underline Animation */}
                <span className="absolute bottom-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-cyan-400 to-transparent -translate-x-full group-hover:translate-x-0 transition-transform duration-500 ease-out" />
              </li>
            ))}
          </ul>

          {/* --- ACTIONS --- */}
          <div className="hidden md:flex items-center gap-6">
            <button className="text-gray-400 hover:text-cyan-400 transition-colors">
              <ShoppingBag className="w-5 h-5" />
            </button>
            
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="relative px-6 py-2 bg-cyan-500 text-black font-bold text-xs uppercase tracking-wider rounded-full overflow-hidden group"
            >
              <span className="relative z-10 flex items-center gap-2">
                Order Now <Zap className="w-3 h-3 fill-black" />
              </span>
              <div className="absolute inset-0 bg-white/50 translate-y-[100%] group-hover:translate-y-0 transition-transform duration-300" />
            </motion.button>
          </div>

          {/* --- MOBILE TOGGLE --- */}
          <div className="md:hidden z-50">
            <button
              onClick={() => setIsMobileOpen(!isMobileOpen)}
              className="w-10 h-10 flex items-center justify-center rounded-full border border-white/10 bg-black/50 backdrop-blur-md text-white active:scale-90 transition-transform"
            >
              {isMobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </motion.nav>

      {/* --- MOBILE OVERLAY --- */}
      <AnimatePresence>
        {isMobileOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.4 }}
            className="fixed inset-0 z-[90] bg-black/95 backdrop-blur-2xl md:hidden flex flex-col items-center justify-center"
          >
            {/* Background Ambient Glow */}
            <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-cyan-500/20 rounded-full blur-[100px]" />
            <div className="absolute bottom-1/4 right-1/4 w-64 h-64 bg-purple-500/20 rounded-full blur-[100px]" />

            <div className="w-full max-w-sm px-6 flex flex-col gap-6 relative z-10">
              {LINKS.map((link, idx) => (
                <motion.a
                  key={link.name}
                  href={link.href}
                  initial={{ x: -50, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  transition={{ delay: 0.1 + idx * 0.1, duration: 0.5, type: "spring" }}
                  onClick={() => setIsMobileOpen(false)}
                  className="group flex items-center justify-between text-2xl font-light text-white border-b border-white/10 pb-4"
                >
                  <span className="group-hover:text-cyan-400 transition-colors">
                    {link.name}
                  </span>
                  <ArrowRight className="w-5 h-5 -rotate-45 opacity-0 group-hover:opacity-100 group-hover:rotate-0 transition-all duration-300 text-cyan-400" />
                </motion.a>
              ))}

              <motion.button
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.6 }}
                className="mt-8 w-full py-4 bg-cyan-500 hover:bg-cyan-400 text-black font-bold text-lg rounded-xl transition-colors flex items-center justify-center gap-2"
              >
                Start Your Order
              </motion.button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}