/* eslint-disable no-unused-vars */
import React, { useRef } from "react";
import { motion, useInView, useScroll, useTransform } from "framer-motion";
import { Target, Cpu, Globe, Zap, Layers, Database } from "lucide-react";

// --- Sub-Component: Infinite Marquee ---
const Marquee = () => {
  return (
    <div className="relative flex overflow-hidden border-y border-white/10 bg-black/40 py-4 mb-16">
      <div className="absolute inset-y-0 left-0 w-32 bg-gradient-to-r from-black to-transparent z-10" />
      <div className="absolute inset-y-0 right-0 w-32 bg-gradient-to-l from-black to-transparent z-10" />
      
      <motion.div
        className="flex whitespace-nowrap gap-16 text-cyan-500/40 font-mono text-sm tracking-[0.2em] uppercase"
        animate={{ x: [0, -1000] }}
        transition={{ repeat: Infinity, duration: 20, ease: "linear" }}
      >
        {[...Array(2)].map((_, i) => (
          <React.Fragment key={i}>
            <span>System Integrity: 100%</span>
            <span>//</span>
            <span>Autonomous Navigation</span>
            <span>//</span>
            <span>Thermal Imaging</span>
            <span>//</span>
            <span>Neural Networks</span>
            <span>//</span>
            <span>Defense Grade Encryption</span>
            <span>//</span>
            <span>LiDAR Mapping</span>
            <span>//</span>
            <span>Real-time Telemetry</span>
            <span>//</span>
          </React.Fragment>
        ))}
      </motion.div>
    </div>
  );
};

// --- Sub-Component: Animated Radar ---
const Radar = () => (
  <div className="relative w-full h-full min-h-[200px] flex items-center justify-center overflow-hidden bg-black/20 rounded-2xl border border-white/5">
    {/* Grid Lines */}
    <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.05)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.05)_1px,transparent_1px)] bg-[size:40px_40px]" />
    
    {/* Concentric Circles */}
    <div className="absolute w-[200px] h-[200px] rounded-full border border-cyan-500/20" />
    <div className="absolute w-[120px] h-[120px] rounded-full border border-cyan-500/20" />
    <div className="absolute w-[10px] h-[10px] rounded-full bg-cyan-400 shadow-[0_0_10px_#22d3ee]" />

    {/* Rotating Radar Sweep */}
    <motion.div
      animate={{ rotate: 360 }}
      transition={{ repeat: Infinity, duration: 4, ease: "linear" }}
      className="absolute w-[200px] h-[200px] rounded-full bg-[conic-gradient(from_0deg,transparent_0deg,transparent_270deg,rgba(34,211,238,0.2)_360deg)]"
    />
    
    {/* Blips */}
    <motion.div
      animate={{ opacity: [0, 1, 0] }}
      transition={{ repeat: Infinity, duration: 2, delay: 0.5 }}
      className="absolute top-1/3 left-1/3 w-2 h-2 bg-red-500 rounded-full shadow-[0_0_8px_#ef4444]"
    />
    <motion.div
      animate={{ opacity: [0, 1, 0] }}
      transition={{ repeat: Infinity, duration: 3, delay: 1.5 }}
      className="absolute bottom-1/3 right-1/4 w-2 h-2 bg-red-500 rounded-full shadow-[0_0_8px_#ef4444]"
    />
  </div>
);

// --- Sub-Component: Bento Card ---
const Card = ({ children, className, delay = 0 }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true }}
    transition={{ duration: 0.6, delay }}
    className={`p-6 md:p-8 rounded-3xl bg-white/5 border border-white/10 backdrop-blur-sm hover:border-white/20 transition-colors ${className}`}
  >
    {children}
  </motion.div>
);

export default function About() {
  const ref = useRef(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end start"] });
  const y = useTransform(scrollYProgress, [0, 1], [-50, 50]);

  return (
    <section ref={ref} className="relative py-32 bg-black overflow-hidden">
      
      {/* Background Decor */}
      <div className="absolute left-0 top-0 w-full h-px bg-gradient-to-r from-transparent via-purple-500/50 to-transparent" />
      <motion.div style={{ y }} className="absolute -right-20 top-40 w-96 h-96 bg-cyan-900/10 rounded-full blur-[100px]" />

      <Marquee />

      <div className="max-w-7xl mx-auto px-6">
        
        {/* --- Header Section --- */}
        <motion.div 
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="mb-16 md:flex justify-between items-end"
        >
          <div className="max-w-2xl">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Engineering the <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-cyan-400">
                Unseen Future.
              </span>
            </h2>
            <p className="text-gray-400 text-lg leading-relaxed">
              We don't just build drones; we engineer intelligent aerial ecosystems. 
              From <span className="text-white">autonomous crop yield optimization</span> to 
              <span className="text-white"> defense-grade surveillance grids</span>, 
              Canopy Puffs is defined by resilience, precision, and mission readiness.
            </p>
          </div>
          
          <div className="hidden md:block text-right">
            <div className="text-xs text-gray-500 font-mono mb-2">FOUNDING DATE</div>
            <div className="text-2xl font-bold text-white">2023 // EST</div>
          </div>
        </motion.div>

        {/* --- Bento Grid Layout --- */}
        <div className="grid grid-cols-1 md:grid-cols-6 md:grid-rows-2 gap-4 h-auto md:h-[600px]">
          
          {/* Card 1: Core Mission (Large) */}
          <Card className="md:col-span-4 md:row-span-2 flex flex-col justify-between group overflow-hidden relative">
             <div className="absolute inset-0 bg-gradient-to-br from-purple-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
             
             <div>
               <div className="w-12 h-12 bg-purple-500/20 rounded-xl flex items-center justify-center mb-6 text-purple-400">
                 <Layers className="w-6 h-6" />
               </div>
               <h3 className="text-2xl font-bold text-white mb-4">Multi-Layered Intelligence</h3>
               <p className="text-gray-400 leading-relaxed">
                 Our proprietary <span className="text-purple-400">CanopyOS</span> software fuses thermal data, LiDAR mapping, and AI object recognition into a single dashboard. Whether you are tracking crop health in the Midwest or monitoring perimeters in a conflict zone, the data is instantaneous.
               </p>
             </div>

             {/* Tech Stack Mini-Grid */}
             <div className="grid grid-cols-2 gap-4 mt-8 pt-8 border-t border-white/10">
               <div>
                 <div className="text-3xl font-bold text-white">0.02s</div>
                 <div className="text-xs text-gray-500 font-mono mt-1">LATENCY SPEED</div>
               </div>
               <div>
                 <div className="text-3xl font-bold text-white">4K</div>
                 <div className="text-xs text-gray-500 font-mono mt-1">VIDEO FEED</div>
               </div>
             </div>
          </Card>

          {/* Card 2: Global Reach (Radar Visual) */}
          <Card className="md:col-span-2 flex flex-col relative" delay={0.2}>
            <div className="flex items-center justify-between mb-4">
               <h4 className="text-sm font-bold text-white flex items-center gap-2">
                 <Globe className="w-4 h-4 text-cyan-400" /> Active Sectors
               </h4>
               <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
            </div>
            <Radar />
          </Card>

          {/* Card 3: Sensors */}
          <Card className="md:col-span-1 bg-gradient-to-br from-cyan-900/20 to-black/40" delay={0.3}>
             <Cpu className="w-8 h-8 text-cyan-400 mb-4" />
             <div className="text-2xl font-bold text-white mb-1">64+</div>
             <div className="text-xs text-gray-500">SENSORS ONBOARD</div>
          </Card>

          {/* Card 4: Data Processing */}
          <Card className="md:col-span-1" delay={0.4}>
             <Database className="w-8 h-8 text-purple-400 mb-4" />
             <div className="text-2xl font-bold text-white mb-1">5PB</div>
             <div className="text-xs text-gray-500">DATA PROCESSED</div>
          </Card>

        </div>
      </div>
    </section>
  );
}