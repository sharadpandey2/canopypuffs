import React, { useRef } from "react";
import { 
  motion, 
  useMotionTemplate, 
  useMotionValue, 
  useSpring 
} from "framer-motion";
import { 
  Sprout, 
  ShieldAlert, 
  Scan, 
  Satellite, 
  Droplets, 
  Target, 
  ArrowUpRight,
  Cpu
} from "lucide-react";
import { clsx } from "clsx";
import { twMerge } from "tailwind-merge";

function cn(...inputs) {
  return twMerge(clsx(inputs));
}

// --- 3D TILT CARD COMPONENT ---
const TiltCard = ({ title, subtitle, theme, icon: Icon, features, index }) => {
  const ref = useRef(null);

  // Mouse Physics
  const x = useMotionValue(0);
  const y = useMotionValue(0);

  // Smooth spring animation for the tilt
  const mouseX = useSpring(x, { stiffness: 500, damping: 100 });
  const mouseY = useSpring(y, { stiffness: 500, damping: 100 });

  function onMouseMove({ currentTarget, clientX, clientY }) {
    const { left, top, width, height } = currentTarget.getBoundingClientRect();
    const xPct = (clientX - left) / width - 0.5;
    const yPct = (clientY - top) / height - 0.5;
    
    // Rotate X is based on Y position (tilt up/down)
    // Rotate Y is based on X position (tilt left/right)
    x.set(xPct);
    y.set(yPct);
  }

  function onMouseLeave() {
    x.set(0);
    y.set(0);
  }

  // Dynamic Transform styles
  const rotateX = useMotionTemplate`${mouseY.get() * -20}deg`;
  const rotateY = useMotionTemplate`${mouseX.get() * 20}deg`;
  
  // Dynamic Spotlight Gradient
  const spotlight = useMotionTemplate`radial-gradient(650px circle at ${
    mouseX.get() * 100 + 50
  }% ${mouseY.get() * 100 + 50}%, ${
    theme === "cyan" ? "rgba(34, 211, 238, 0.15)" : "rgba(168, 85, 247, 0.15)"
  }, transparent 80%)`;

  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.2 }}
      viewport={{ once: true }}
      className="relative w-full h-full"
      style={{ perspective: 1000 }}
    >
      <motion.div
        ref={ref}
        onMouseMove={onMouseMove}
        onMouseLeave={onMouseLeave}
        style={{ rotateX, rotateY, transformStyle: "preserve-3d" }}
        className={cn(
          "relative h-full overflow-hidden rounded-3xl border border-white/10 bg-black/50 backdrop-blur-sm p-8 md:p-12 group transition-colors duration-500",
          theme === "cyan" ? "hover:border-cyan-500/50" : "hover:border-purple-500/50"
        )}
      >
        {/* Spotlight Overlay */}
        <motion.div
          style={{ background: spotlight }}
          className="absolute inset-0 z-0 transition-opacity duration-500 opacity-0 group-hover:opacity-100"
        />

        {/* --- CARD CONTENT (Popped out in 3D) --- */}
        <div style={{ transform: "translateZ(50px)" }} className="relative z-10 flex flex-col h-full">
          
          {/* Header */}
          <div className="flex justify-between items-start mb-8">
            <div className={cn(
              "p-4 rounded-2xl border bg-opacity-10 backdrop-blur-md",
              theme === "cyan" 
                ? "bg-cyan-500 border-cyan-500/30 text-cyan-400" 
                : "bg-purple-500 border-purple-500/30 text-purple-400"
            )}>
              <Icon className="w-8 h-8" />
            </div>
            
            <ArrowUpRight className="w-6 h-6 text-gray-600 group-hover:text-white transition-colors" />
          </div>

          <h3 className="text-4xl font-black text-white mb-2 tracking-tight">
            {title}
          </h3>
          <p className={cn(
            "text-sm font-bold tracking-widest uppercase mb-8",
            theme === "cyan" ? "text-cyan-500" : "text-purple-500"
          )}>
            {subtitle}
          </p>

          {/* Feature List */}
          <ul className="space-y-4 mb-10 flex-grow">
            {features.map((item, idx) => (
              <li key={idx} className="flex items-center gap-3 text-gray-400 group-hover:text-gray-200 transition-colors">
                <div className={cn(
                  "w-1.5 h-1.5 rounded-full shadow-[0_0_10px]",
                  theme === "cyan" ? "bg-cyan-400 shadow-cyan-400" : "bg-purple-400 shadow-purple-400"
                )} />
                <span className="text-sm font-medium">{item}</span>
              </li>
            ))}
          </ul>

          {/* Action Button */}
          <button className={cn(
            "w-full py-4 rounded-xl font-bold uppercase tracking-wider text-xs transition-all flex items-center justify-center gap-2",
            "bg-white/5 border border-white/10 hover:bg-white text-white hover:text-black",
            theme === "cyan" ? "hover:shadow-[0_0_30px_-5px_rgba(34,211,238,0.6)]" : "hover:shadow-[0_0_30px_-5px_rgba(168,85,247,0.6)]"
          )}>
            Explore System <Cpu className="w-4 h-4" />
          </button>
        </div>

        {/* Decorative Background Grid inside card */}
        <div className="absolute inset-0 z-0 bg-[linear-gradient(to_right,#4f4f4f2e_1px,transparent_1px),linear-gradient(to_bottom,#4f4f4f2e_1px,transparent_1px)] bg-[size:2rem_2rem] opacity-20" />
      </motion.div>
    </motion.div>
  );
};

export default function Solutions() {
  return (
    <section className="relative py-32 px-6 overflow-hidden">
      
      {/* Background Ambient Glows */}
      <div className="absolute top-0 right-0 w-[800px] h-[800px] bg-purple-900/10 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-[800px] h-[800px] bg-cyan-900/10 rounded-full blur-[120px] pointer-events-none" />

      <div className="max-w-7xl mx-auto">
        
        {/* Section Header */}
        <div className="text-center mb-24">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-white/10 bg-white/5 text-xs text-gray-400 mb-6"
          >
            <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
            OPERATIONAL CAPABILITIES
          </motion.div>
          
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            viewport={{ once: true }}
            className="text-5xl md:text-6xl font-black text-white tracking-tight"
          >
            Choose Your <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-500">Vector.</span>
          </motion.h2>
        </div>

        {/* Grid Layout */}
        <div className="grid md:grid-cols-2 gap-8 lg:gap-16">
          
          {/* 1. Agriculture Card */}
          <TiltCard 
            index={0}
            title="AGRI-TECH"
            subtitle="Precision Farming Systems"
            theme="cyan"
            icon={Sprout}
            features={[
              "Multispectral Crop Analysis",
              "Automated Pesticide Spraying",
              "Soil Health Telemetry",
              "24/7 Field Monitoring",
              "Yield Prediction Algorithms"
            ]}
          />

          {/* 2. Defense Card */}
          <TiltCard 
            index={1}
            title="DEFENSE"
            subtitle="Tactical Surveillance Units"
            theme="purple"
            icon={ShieldAlert}
            features={[
              "Thermal / Night Vision Optics",
              "AES-256 Encrypted Datalink",
              "Autonomous Target Tracking",
              "Perimeter Breach Detection",
              "Anti-Jamming GPS Navigation"
            ]}
          />
        </div>

        {/* Bottom Stat Strip */}
        <div className="mt-24 grid grid-cols-2 md:grid-cols-4 gap-8 border-t border-white/10 pt-12">
          {[
            { label: "Flight Hours", value: "10,000+" },
            { label: "Hectares Mapped", value: "500K+" },
            { label: "Active Units", value: "120" },
            { label: "Success Rate", value: "99.9%" }
          ].map((stat, i) => (
            <motion.div 
              key={i}
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              transition={{ delay: 0.5 + (i * 0.1) }}
              className="text-center"
            >
              <h4 className="text-3xl font-bold text-white mb-1">{stat.value}</h4>
              <p className="text-xs text-gray-500 uppercase tracking-widest">{stat.label}</p>
            </motion.div>
          ))}
        </div>

      </div>
    </section>
  );
}