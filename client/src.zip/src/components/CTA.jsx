import React, { useState, useRef } from "react";
import { motion, useScroll, useTransform, useInView } from "framer-motion";
import { Send, CheckCircle, ArrowRight, Shield, Globe, Zap } from "lucide-react";
import { clsx } from "clsx";
import { twMerge } from "tailwind-merge";

function cn(...inputs) {
  return twMerge(clsx(inputs));
}

// --- Background Grid Animation ---
const GridBackground = () => {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {/* Moving Grid */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#4f4f4f2e_1px,transparent_1px),linear-gradient(to_bottom,#4f4f4f2e_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)] opacity-20" />
      
      {/* Floating Orbs */}
      <motion.div 
        animate={{ opacity: [0.3, 0.6, 0.3], scale: [1, 1.2, 1] }}
        transition={{ duration: 5, repeat: Infinity }}
        className="absolute top-0 left-1/4 w-[500px] h-[500px] bg-cyan-500/20 rounded-full blur-[120px]" 
      />
      <motion.div 
        animate={{ opacity: [0.2, 0.5, 0.2], scale: [1.2, 1, 1.2] }}
        transition={{ duration: 7, repeat: Infinity }}
        className="absolute bottom-0 right-1/4 w-[500px] h-[500px] bg-purple-500/20 rounded-full blur-[120px]" 
      />
    </div>
  );
};

// --- Feature Badge Component ---
const FeatureBadge = ({ icon: Icon, text, delay }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true }}
    transition={{ delay, duration: 0.5 }}
    className="flex items-center gap-2 px-4 py-2 rounded-full border border-white/10 bg-white/5 backdrop-blur-md text-xs font-medium text-gray-300"
  >
    <Icon className="w-3.5 h-3.5 text-cyan-400" />
    {text}
  </motion.div>
);

export default function CTA() {
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState("idle"); // idle, loading, success
  const containerRef = useRef(null);
  
  // Parallax Effect
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start end", "end start"],
  });

  const y = useTransform(scrollYProgress, [0, 1], [-50, 50]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!email) return;
    setStatus("loading");
    // Simulate API call
    setTimeout(() => setStatus("success"), 1500);
  };

  return (
    <section 
      ref={containerRef}
      className="relative py-32 overflow-hidden border-t border-white/10"
    >
      <GridBackground />

      <div className="relative z-10 max-w-4xl mx-auto px-6 text-center">
        
        {/* --- Top Badges --- */}
        <div className="flex flex-wrap justify-center gap-3 mb-12">
          <FeatureBadge icon={Shield} text="Military-Grade Security" delay={0} />
          <FeatureBadge icon={Globe} text="Global Logistics" delay={0.1} />
          <FeatureBadge icon={Zap} text="Next-Gen Propulsion" delay={0.2} />
        </div>

        {/* --- Main Headline --- */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          whileInView={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8 }}
        >
          <h2 className="text-5xl md:text-7xl font-bold tracking-tight text-white mb-6">
            Ready to <br />
            <span className="relative inline-block text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-cyan-200 to-purple-400">
              ASCEND WITH US?
              {/* Glitch underline effect */}
              <motion.span 
                className="absolute -bottom-2 left-0 w-full h-1 bg-cyan-500"
                initial={{ scaleX: 0 }}
                whileInView={{ scaleX: 1 }}
                transition={{ delay: 0.5, duration: 0.8 }}
              />
            </span>
          </h2>
        </motion.div>

        <motion.p 
          className="text-lg text-gray-400 max-w-2xl mx-auto mb-12 leading-relaxed"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          Initiate a sequence with Canopy Puffs. Whether for commercial partnerships, 
          technology demos, or <span className="text-cyan-400">defense contracts</span>, 
          we are ready to deploy.
        </motion.p>

        {/* --- Interactive Form Card --- */}
        <motion.div 
          style={{ y }}
          className="relative max-w-md mx-auto"
        >
          {/* Glowing Border Container */}
          <div className="absolute -inset-1 bg-gradient-to-r from-cyan-500 via-purple-500 to-cyan-500 rounded-2xl opacity-75 blur transition duration-1000 group-hover:opacity-100 animate-gradient-xy" />
          
          <div className="relative p-2 bg-black rounded-2xl border border-white/10 ring-1 ring-white/10">
            <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-2">
              <input 
                type="email" 
                placeholder="Enter official communication frequency (Email)"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                disabled={status === "success"}
                className="flex-1 bg-white/5 text-white placeholder-gray-500 px-6 py-4 rounded-xl focus:outline-none focus:ring-2 focus:ring-cyan-500/50 transition-all text-sm"
              />
              
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                disabled={status !== "idle"}
                className={cn(
                  "px-8 py-4 rounded-xl font-bold text-sm uppercase tracking-wider transition-all flex items-center justify-center gap-2 min-w-[160px]",
                  status === "success" 
                    ? "bg-green-500 text-black" 
                    : "bg-cyan-500 text-black hover:bg-cyan-400 hover:shadow-[0_0_20px_-5px_rgba(34,211,238,0.5)]"
                )}
              >
                {status === "idle" && (
                  <>
                    Initiate <ArrowRight className="w-4 h-4" />
                  </>
                )}
                {status === "loading" && (
                  <motion.div 
                    animate={{ rotate: 360 }}
                    transition={{ repeat: Infinity, duration: 1 }}
                    className="w-5 h-5 border-2 border-black border-t-transparent rounded-full"
                  />
                )}
                {status === "success" && (
                  <>
                    Sent <CheckCircle className="w-4 h-4" />
                  </>
                )}
              </motion.button>
            </form>
          </div>
        </motion.div>

        {/* --- Footer Links / Stats --- */}
        <div className="mt-20 pt-10 border-t border-white/5 flex flex-col md:flex-row justify-between items-center text-xs text-gray-500 gap-6">
          <div className="flex gap-8">
            <a href="#" className="hover:text-cyan-400 transition-colors">Privacy Protocol</a>
            <a href="#" className="hover:text-cyan-400 transition-colors">Terms of Engagement</a>
            <a href="#" className="hover:text-cyan-400 transition-colors">Security Clearance</a>
          </div>
          
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
            System Status: Operational
          </div>
        </div>

      </div>
    </section>
  );
}