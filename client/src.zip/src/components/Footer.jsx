/* eslint-disable no-unused-vars */
import React from "react";
import { motion } from "framer-motion";
import { Cloud, Github, Twitter, Linkedin, Instagram, ArrowUpRight } from "lucide-react";

const SocialLink = ({ icon: Icon, href }) => (
  <motion.a
    href={href}
    whileHover={{ y: -5, color: "#22d3ee" }}
    className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-gray-400 transition-colors hover:border-cyan-500/50 hover:bg-cyan-500/10"
  >
    <Icon className="w-5 h-5" />
  </motion.a>
);

const FooterLink = ({ text }) => (
  <li>
    <a href="#" className="group flex items-center gap-2 text-gray-400 hover:text-cyan-400 transition-colors text-sm">
      <span className="w-0 group-hover:w-2 h-px bg-cyan-400 transition-all duration-300" />
      {text}
    </a>
  </li>
);

export default function Footer() {
  return (
    <footer className="relative bg-black border-t border-white/10 pt-20 pb-10 overflow-hidden">
      
      {/* Background Grid */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#4f4f4f2e_1px,transparent_1px),linear-gradient(to_bottom,#4f4f4f2e_1px,transparent_1px)] bg-[size:4rem_4rem] opacity-20 pointer-events-none" />

      {/* Massive Background Text (Visual only) */}
      <div className="absolute bottom-0 left-0 right-0 overflow-hidden pointer-events-none select-none">
        <h1 className="text-[15vw] font-black text-white/5 leading-none tracking-tighter text-center translate-y-[20%]">
          CANOPY
        </h1>
      </div>

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-12 mb-20">
          
          {/* Brand Column */}
          <div className="md:col-span-5 space-y-6">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-cyan-500/10 border border-cyan-500/20 rounded-lg flex items-center justify-center">
                <Cloud className="w-4 h-4 text-cyan-400" />
              </div>
              <span className="text-xl font-bold text-white tracking-widest">
                CANOPY PUFFS
              </span>
            </div>
            <p className="text-gray-400 max-w-sm leading-relaxed">
              Redefining aerial dominance through autonomous systems. 
              Built for the farm, hardened for the frontline.
            </p>
            
            <div className="flex gap-4 pt-4">
              <SocialLink icon={Github} href="#" />
              <SocialLink icon={Twitter} href="#" />
              <SocialLink icon={Linkedin} href="#" />
              <SocialLink icon={Instagram} href="#" />
            </div>
          </div>

          {/* Links Column 1 */}
          <div className="md:col-span-2">
            <h4 className="text-white font-bold mb-6">Platform</h4>
            <ul className="space-y-4">
              <FooterLink text="Agriculture Drones" />
              <FooterLink text="Defense Systems" />
              <FooterLink text="CanopyOS Software" />
              <FooterLink text="Autonomous Fleet" />
            </ul>
          </div>

          {/* Links Column 2 */}
          <div className="md:col-span-2">
            <h4 className="text-white font-bold mb-6">Company</h4>
            <ul className="space-y-4">
              <FooterLink text="Mission Brief" />
              <FooterLink text="Engineering Team" />
              <FooterLink text="Investor Relations" />
              <FooterLink text="Careers / Deploy" />
            </ul>
          </div>

          {/* Status Column */}
          <div className="md:col-span-3">
            <div className="p-6 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-sm">
              <h4 className="text-sm font-bold text-gray-300 mb-4 uppercase tracking-wider">System Status</h4>
              
              <div className="space-y-3">
                <div className="flex justify-between items-center text-sm">
                  <span className="text-gray-500">Servers</span>
                  <span className="text-green-400 flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" /> Online
                  </span>
                </div>
                <div className="flex justify-between items-center text-sm">
                  <span className="text-gray-500">Encryption</span>
                  <span className="text-cyan-400">AES-256 Active</span>
                </div>
                <div className="flex justify-between items-center text-sm">
                  <span className="text-gray-500">Sat-Link</span>
                  <span className="text-green-400">Connected</span>
                </div>
              </div>

              <button className="mt-6 w-full py-3 bg-white/10 hover:bg-white/20 text-white text-xs font-bold uppercase tracking-widest rounded-lg transition-colors flex items-center justify-center gap-2">
                Initiate Login <ArrowUpRight className="w-3 h-3" />
              </button>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-white/10 flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-gray-500">
          <p>© 2025 CANOPY PUFFS AEROSPACE. ALL RIGHTS RESERVED.</p>
          <div className="flex gap-8">
            <a href="#" className="hover:text-cyan-400 transition-colors">PRIVACY PROTOCOL</a>
            <a href="#" className="hover:text-cyan-400 transition-colors">TERMS OF ENGAGEMENT</a>
          </div>
        </div>
      </div>
    </footer>
  );
}