/* eslint-disable no-unused-vars */
import React, { useEffect, useRef } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { Crosshair, Cpu, Battery, Wifi, ChevronDown, PlayCircle, ShieldCheck } from "lucide-react";

// --- Configuration ---
// REPLACE THIS with your actual image path in src/assets/images/
const HERO_IMAGE_URL = "https://images.unsplash.com/photo-1473968512647-3e447244af8f?q=80&w=2070&auto=format&fit=crop"; 

// --- Animation Variants ---
const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.2, delayChildren: 0.3 }
  }
};

const itemVariants = {
  hidden: { y: 30, opacity: 0, filter: "blur(10px)" },
  visible: { 
    y: 0, 
    opacity: 1, 
    filter: "blur(0px)",
    transition: { duration: 0.8, ease: "easeOut" }
  }
};

const glitchVariants = {
  hidden: { skew: 0 },
  visible: { 
    skew: [-2, 2, -1, 0],
    transition: { repeat: Infinity, repeatDelay: 5, duration: 0.5 } 
  }
};

// --- Sub-Components ---

const StatBadge = ({ icon: Icon, label, value }) => (
  <div className="flex items-center gap-3 px-4 py-2 bg-black/40 backdrop-blur-md border border-white/10 rounded-lg">
    <Icon className="w-5 h-5 text-cyan-400" />
    <div className="flex flex-col leading-none">
      <span className="text-[10px] text-gray-400 uppercase tracking-wider">{label}</span>
      <span className="text-sm font-bold text-white font-mono">{value}</span>
    </div>
  </div>
);

const HUDCorner = ({ className }) => (
  <div className={`absolute w-16 h-16 border-cyan-500/30 ${className}`}>
    <div className="absolute inset-0 border-2 border-transparent" />
  </div>
);

// --- Main Hero Component ---

export default function Hero() {
  const ref = useRef(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start start", "end start"],
  });

  const y = useTransform(scrollYProgress, [0, 1], ["0%", "50%"]);
  const opacity = useTransform(scrollYProgress, [0, 0.8], [1, 0]);

  return (
    <section 
      ref={ref} 
      className="relative min-h-screen flex items-center justify-center px-6 overflow-hidden pt-20" // pt-20 to clear Navbar
    >
      {/* --- BACKGROUND LAYER --- */}
      <div className="absolute inset-0 z-0">
        <motion.div style={{ y, opacity }} className="absolute inset-0">
          {/* Hero Image */}
          <div 
            className="absolute inset-0 bg-cover bg-center bg-no-repeat scale-105"
            style={{ backgroundImage: `url(${HERO_IMAGE_URL})` }}
          />
          {/* Overlay Gradient for readability */}
          <div className="absolute inset-0 bg-gradient-to-b from-black/80 via-black/40 to-black/90" />
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_0%,#000_100%)] opacity-80" />
        </motion.div>
        
        {/* Animated Grid Scanline */}
        <div className="absolute inset-0 bg-[linear-gradient(to_bottom,transparent_50%,rgba(34,211,238,0.03)_50%)] bg-[size:100%_4px] pointer-events-none" />
      </div>

      {/* --- HUD INTERFACE LAYER --- */}
      <div className="absolute inset-0 z-10 pointer-events-none px-6 py-6 md:p-12">
        {/* Top Left Status */}
        <div className="absolute top-24 left-6 md:left-12 flex items-center gap-2 text-xs font-mono text-cyan-500/60">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-cyan-500"></span>
          </span>
          SYSTEM ONLINE // V.2.0.4
        </div>

        {/* Decorative Corners (Like a camera viewfinder) */}
        <HUDCorner className="top-24 left-6 border-t-2 border-l-2 rounded-tl-2xl" />
        <HUDCorner className="top-24 right-6 border-t-2 border-r-2 rounded-tr-2xl" />
        <HUDCorner className="bottom-6 left-6 border-b-2 border-l-2 rounded-bl-2xl" />
        <HUDCorner className="bottom-6 right-6 border-b-2 border-r-2 rounded-br-2xl" />
      </div>

      {/* --- CONTENT LAYER --- */}
      <motion.div
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        className="relative z-20 text-center max-w-5xl mx-auto"
      >
        {/* Badge */}
        <motion.div variants={itemVariants} className="flex justify-center mb-6">
          <div className="px-4 py-1.5 rounded-full border border-cyan-500/30 bg-cyan-500/10 text-cyan-300 text-xs font-bold tracking-[0.2em] uppercase backdrop-blur-md shadow-[0_0_20px_-5px_rgba(34,211,238,0.4)]">
            Defense & Agriculture Systems
          </div>
        </motion.div>

        {/* Main Title */}
        <motion.h1 variants={itemVariants} className="text-6xl md:text-8xl font-black leading-tight tracking-tighter text-white mb-6">
          <motion.span variants={glitchVariants} className="block">
            AUTONOMOUS
          </motion.span>
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-white to-purple-500 filter drop-shadow-[0_0_20px_rgba(34,211,238,0.3)]">
            AERIAL SUPERIORITY
          </span>
        </motion.h1>

        {/* Subtitle */}
        <motion.p variants={itemVariants} className="text-lg md:text-xl text-gray-300 max-w-2xl mx-auto leading-relaxed mb-10">
          Canopy Puffs engineers next-gen <span className="text-white font-bold">UAVs</span> designed for 
          hyper-precision farming and military-grade surveillance operations.
        </motion.p>

        {/* Actions */}
        <motion.div variants={itemVariants} className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-16">
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="group relative px-8 py-4 bg-cyan-500 text-black font-bold text-sm uppercase tracking-widest rounded-lg overflow-hidden"
          >
            <span className="relative z-10 flex items-center gap-2">
              Deploy Drones <Crosshair className="w-4 h-4" />
            </span>
            <div className="absolute inset-0 bg-white/40 translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-500" />
          </motion.button>

          <motion.button
            whileHover={{ scale: 1.05, borderColor: "rgba(34,211,238,0.8)" }}
            whileTap={{ scale: 0.95 }}
            className="px-8 py-4 bg-black/50 backdrop-blur-sm border border-white/20 text-white font-bold text-sm uppercase tracking-widest rounded-lg flex items-center gap-2 hover:bg-white/5 transition-all"
          >
            <PlayCircle className="w-4 h-4 text-cyan-400" />
            Watch Showreel
          </motion.button>
        </motion.div>

        {/* Live Specs Bar (Floating Glass Card) */}
        <motion.div 
          variants={itemVariants}
          className="hidden md:flex items-center justify-center gap-4"
        >
          <div className="p-1 rounded-xl bg-gradient-to-r from-white/10 to-transparent">
            <div className="px-8 py-4 bg-black/80 backdrop-blur-xl rounded-lg border border-white/10 flex items-center gap-8">
              <StatBadge icon={Wifi} label="Range" value="15 KM" />
              <div className="w-px h-8 bg-white/10" />
              <StatBadge icon={Battery} label="Endurance" value="45 MIN" />
              <div className="w-px h-8 bg-white/10" />
              <StatBadge icon={ShieldCheck} label="Security" value="AES-256" />
              <div className="w-px h-8 bg-white/10" />
              <StatBadge icon={Cpu} label="AI Core" value="NVIDIA" />
            </div>
          </div>
        </motion.div>
      </motion.div>

      {/* Scroll Indicator */}
      <motion.div 
        animate={{ y: [0, 10, 0] }}
        transition={{ repeat: Infinity, duration: 2 }}
        className="absolute bottom-10 left-1/2 -translate-x-1/2 text-cyan-500/50"
      >
        <ChevronDown className="w-8 h-8" />
      </motion.div>
    </section>
  );
}